/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author Leonardo
 */
public class Huesped extends persona{
    
    private String codhuesped;

    public Huesped() {
    }

    public Huesped(String codhuesped) {
        this.codhuesped = codhuesped;
    }

    public String getCodhuesped() {
        return codhuesped;
    }

    public void setCodhuesped(String codhuesped) {
        this.codhuesped = codhuesped;
    }
      
    
}
