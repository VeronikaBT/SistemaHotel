/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package Vista;

/**
 *
 * @author JF
 */

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartFrame;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.data.category.DefaultCategoryDataset;

import java.awt.Color;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.TextStyle;
import java.util.Locale;
import org.jfree.chart.labels.ItemLabelAnchor;
import org.jfree.chart.labels.ItemLabelPosition;
import org.jfree.chart.labels.StandardCategoryItemLabelGenerator;
import org.jfree.ui.TextAnchor;
import utils.Conexion;
public class frmganancias extends javax.swing.JFrame {

    /**
     * Creates new form frmganacias
     */
    public frmganancias() {
             generarGrafico();
    }
 private void generarGrafico() {
     Conexion conexion = new Conexion();

    try (Connection connection = conexion.conectar()) {

         
            String ingresosQuery = "SELECT MONTH(fecha_pago) AS mes, SUM(total_pago) AS total_pago_mes FROM pago GROUP BY MONTH(fecha_pago)";
            Statement ingresosStatement = connection.createStatement();
            ResultSet ingresosResultSet = ingresosStatement.executeQuery(ingresosQuery);


            String gastosQuery = "SELECT MONTH(fechapedido) AS mes, SUM(costo) AS costo_mes FROM pedido GROUP BY MONTH(fechapedido)";
            Statement gastosStatement = connection.createStatement();
            ResultSet gastosResultSet = gastosStatement.executeQuery(gastosQuery);


            DefaultCategoryDataset ingresosDataset = new DefaultCategoryDataset();

     
            while (ingresosResultSet.next()) {
                int mes = ingresosResultSet.getInt("mes");
                double totalPagoMes = ingresosResultSet.getDouble("total_pago_mes");

                String nombreMes = getNombreMes(mes);

                ingresosDataset.addValue(totalPagoMes, "Ingresos", nombreMes);
            }

         
            DefaultCategoryDataset gastosDataset = new DefaultCategoryDataset();

    
            while (gastosResultSet.next()) {
                int mes = gastosResultSet.getInt("mes");
                double totalPedidoMes = gastosResultSet.getDouble("costo_mes");

                String nombreMes = getNombreMes(mes);

                double totalSueldos = getTotalSueldos(connection);

                double gastosTotalesMes = totalPedidoMes + totalSueldos;

                gastosDataset.addValue(gastosTotalesMes, "Gastos", nombreMes);
            }

 
            ingresosResultSet.close();
            ingresosStatement.close();
            gastosResultSet.close();
            gastosStatement.close();
            connection.close();

        
            DefaultCategoryDataset gananciasDataset = new DefaultCategoryDataset();
            for (int i = 0; i < ingresosDataset.getRowCount(); i++) {
                Comparable<?> rowKey = ingresosDataset.getRowKey(i);
                for (int j = 0; j < ingresosDataset.getColumnCount(); j++) {
                   Comparable<?> columnKey = ingresosDataset.getColumnKey(j);
             
                    double ingresos = ingresosDataset.getValue(i, j).doubleValue();
                    double gastos = gastosDataset.getValue(i, j).doubleValue();
                    double ganancias = ingresos - gastos;

                    gananciasDataset.addValue(ganancias, "Ganancias", columnKey);
                }
            }

    
            JFreeChart chart = ChartFactory.createBarChart("Resumen Mensual de Ganancias", "Mes", "Ganancias", gananciasDataset);

         
            CategoryPlot plot = chart.getCategoryPlot();
            BarRenderer renderer = (BarRenderer) plot.getRenderer();
            renderer.setSeriesPaint(0, Color.GREEN); 

   
            ItemLabelPosition position = new ItemLabelPosition(ItemLabelAnchor.OUTSIDE12, TextAnchor.TOP_CENTER);
            renderer.setBasePositiveItemLabelPosition(position);
            renderer.setBaseItemLabelGenerator(new StandardCategoryItemLabelGenerator());
            renderer.setBaseItemLabelsVisible(true);

           
            ChartFrame frame = new ChartFrame("Resumen Mensual de Ganancias", chart);
            frame.pack();
            frame.setVisible(true);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static String getNombreMes(int mes) {
        LocalDate fecha = LocalDate.of(2023, mes, 1);
        return fecha.getMonth().getDisplayName(TextStyle.FULL, Locale.getDefault());
    }

    private static double getTotalSueldos(Connection connection) throws SQLException {
        String sueldosQuery = "SELECT SUM(sueldo) AS total_sueldos FROM empleado";
        Statement sueldosStatement = connection.createStatement();
        ResultSet sueldosResultSet = sueldosStatement.executeQuery(sueldosQuery);

        double totalSueldos = 0;
        if (sueldosResultSet.next()) {
            totalSueldos = sueldosResultSet.getDouble("total_sueldos");
        }

        sueldosResultSet.close();
        sueldosStatement.close();

        return totalSueldos;
    }
 
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(frmganancias.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(frmganancias.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(frmganancias.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(frmganancias.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new frmganancias().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
