/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Vista;

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;

public class hb extends JFrame {

    private JButton[] botones;
    private Connection conexion;

    public hb() {
        super("Estado de Habitaciones");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                // Manejar el cierre de la ventana
                cerrarAplicacion();
            }
        });
        setLayout(new FlowLayout());
        setResizable(true);

        // Configurar la matriz de botones
        botones = new JButton[29];
        for (int i = 0; i < botones.length; i++) {
            int numeroHabitacion = i + 1;
            botones[i] = new JButton("Habitación " + numeroHabitacion);
            botones[i].setEnabled(false);
            botones[i].putClientProperty("numeroHabitacion", numeroHabitacion);
            add(botones[i]);
        }

        setLayout(new GridLayout(0, 5));
        pack();

        // Conectar a la base de datos
        try {
            conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/gestionhotel", "root", "");
            buscarEstadosHabitaciones();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        setExtendedState(JFrame.MAXIMIZED_BOTH);
    }

    private void buscarEstadosHabitaciones() {
        String consulta = "SELECT numerohabitacion, estado FROM habitacion";
        try (PreparedStatement statement = conexion.prepareStatement(consulta); ResultSet resultSet = statement.executeQuery()) {
            while (resultSet.next()) {
                int numeroHabitacion = resultSet.getInt("numerohabitacion");
                String estado = resultSet.getString("estado");
                actualizarEstadoHabitacion(numeroHabitacion, estado);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void actualizarEstadoHabitacion(int numeroHabitacion, String estado) {
        for (JButton boton : botones) {
            int habitacion = (int) boton.getClientProperty("numeroHabitacion");
            if (habitacion == numeroHabitacion) {
                Font font = new Font(boton.getFont().getName(), Font.BOLD, 24);
                boton.setFont(font);
                boton.setForeground(Color.BLACK);

                switch (estado) {
                    case "Ocupado":
                        boton.setBackground(Color.RED);
                        break;
                    case "Disponible":
                        boton.setBackground(Color.GREEN);
                        break;
                    case "Mantenimiento":
                        boton.setBackground(Color.YELLOW);
                        break;
                }
                break;
            }
        }
    }

    private void cerrarAplicacion() {
        dispose();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            hb frame = new hb();
            frame.setVisible(true);
        });
    }
}
